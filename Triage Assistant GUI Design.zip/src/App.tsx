import { useState } from 'react';
import { Button } from './components/ui/button';
import { Label } from './components/ui/label';
import { Input } from './components/ui/input';
import { ScrollArea } from './components/ui/scroll-area';
import { FileText, Upload, Trash2, X, Filter } from 'lucide-react';
import { EventIdFilter } from './components/EventIdFilter';

export default function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePath, setFilePath] = useState<string>('');
  const [results, setResults] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [rawLogEntries, setRawLogEntries] = useState<Array<{eventId: string, message: string}>>([]);
  const [selectedEventIds, setSelectedEventIds] = useState<string[]>([]);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setFilePath(file.name);
    }
  };

  const handleBrowseClick = () => {
    document.getElementById('fileInput')?.click();
  };

  const handleAnalyze = async () => {
    if (!selectedFile) {
      setResults('Please select a log file first.');
      return;
    }

    setIsAnalyzing(true);
    setResults('Analyzing log file...\n');

    // Simulate analysis process
    setTimeout(() => {
      // Generate mock log entries with event IDs
      const mockLogEntries = [
        { eventId: '4624', message: 'An account was successfully logged on - 25 occurrences' },
        { eventId: '4625', message: 'An account failed to log on - 12 occurrences' },
        { eventId: '4634', message: 'An account was logged off - 20 occurrences' },
        { eventId: '4672', message: 'Special privileges assigned to new logon - 8 occurrences' },
        { eventId: '4688', message: 'A new process has been created - 45 occurrences' },
        { eventId: '4689', message: 'A process has exited - 42 occurrences' },
        { eventId: '7045', message: 'A service was installed in the system - 3 occurrences' },
        { eventId: '1102', message: 'The audit log was cleared - 1 occurrence' },
        { eventId: '4720', message: 'A user account was created - 2 occurrences' },
        { eventId: '4732', message: 'A member was added to a security-enabled local group - 5 occurrences' },
      ];
      
      setRawLogEntries(mockLogEntries);
      
      const mockResults = `Analysis Results for: ${selectedFile.name}
=====================================

File Information:
- File Name: ${selectedFile.name}
- File Size: ${(selectedFile.size / 1024).toFixed(2)} KB
- File Type: ${selectedFile.type || 'text/plain'}
- Last Modified: ${new Date(selectedFile.lastModified).toLocaleString()}

Analysis Summary:
- Total Lines Processed: ${Math.floor(Math.random() * 10000) + 1000}
- Total Events Found: ${mockLogEntries.length}
- Unique Event IDs: ${mockLogEntries.length}

Event Details:
${mockLogEntries.map(entry => `[Event ID ${entry.eventId}] ${entry.message}`).join('\n')}

Recommendations:
- Review failed logon attempts (Event ID 4625)
- Monitor new process creation patterns
- Investigate audit log clearing (Event ID 1102)
- Review service installations and privilege escalations

Analysis completed at: ${new Date().toLocaleString()}
`;
      setResults(mockResults);
      setIsAnalyzing(false);
    }, 2000);
  };

  // Filter results based on selected event IDs
  const getFilteredResults = () => {
    if (selectedEventIds.length === 0 || rawLogEntries.length === 0) {
      return results;
    }

    const filteredEntries = rawLogEntries.filter(entry => 
      selectedEventIds.includes(entry.eventId)
    );

    if (filteredEntries.length === 0) {
      return 'No results match the selected event ID filters.';
    }

    const header = results.split('Event Details:')[0];
    const footer = results.split('Recommendations:')[1];
    
    return `${header}Event Details (Filtered):
${filteredEntries.map(entry => `[Event ID ${entry.eventId}] ${entry.message}`).join('\n')}

${footer ? 'Recommendations:' + footer : ''}`;
  };

  // Get unique event IDs from raw log entries
  const availableEventIds = Array.from(new Set(rawLogEntries.map(entry => entry.eventId)));

  const handleClearResults = () => {
    setResults('');
  };

  const handleExit = () => {
    if (confirm('Are you sure you want to exit?')) {
      setSelectedFile(null);
      setFilePath('');
      setResults('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-8">
      <div className="w-full max-w-4xl bg-white rounded-lg shadow-xl border border-slate-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4 rounded-t-lg">
          <div className="flex items-center gap-3">
            <FileText className="w-6 h-6" />
            <h1>DuCharme Triage Assistant</h1>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6 space-y-6">
          {/* File Selection Section */}
          <div className="space-y-3">
            <Label htmlFor="filePath" className="text-slate-700">
              Select Log File:
            </Label>
            <div className="flex gap-3">
              <Input
                id="filePath"
                type="text"
                value={filePath}
                placeholder="No file selected"
                readOnly
                className="flex-1 bg-slate-50"
              />
              <Button 
                onClick={handleBrowseClick}
                variant="outline"
                className="gap-2"
              >
                <Upload className="w-4 h-4" />
                Browse...
              </Button>
              <input
                id="fileInput"
                type="file"
                accept=".log,.txt,.json"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </div>

          {/* Analyze Button */}
          <div>
            <Button 
              onClick={handleAnalyze}
              disabled={!selectedFile || isAnalyzing}
              className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700"
            >
              {isAnalyzing ? 'Analyzing...' : 'Analyze'}
            </Button>
          </div>

          {/* Filter Section */}
          {rawLogEntries.length > 0 && (
            <div className="flex items-center gap-3">
              <EventIdFilter
                availableEventIds={availableEventIds}
                selectedEventIds={selectedEventIds}
                onSelectionChange={setSelectedEventIds}
              />
            </div>
          )}

          {/* Results Display Area */}
          <div className="space-y-2">
            <Label className="text-slate-700">Results:</Label>
            <ScrollArea className="h-80 w-full rounded-md border border-slate-200 bg-slate-50">
              <div className="p-4">
                <pre className="whitespace-pre-wrap text-slate-800">
                  {getFilteredResults() || 'No results yet. Select a log file and click Analyze.'}
                </pre>
              </div>
            </ScrollArea>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t border-slate-200">
            <Button
              onClick={handleClearResults}
              variant="outline"
              className="gap-2"
              disabled={!results}
            >
              <Trash2 className="w-4 h-4" />
              Clear Results
            </Button>
            <Button
              onClick={handleExit}
              variant="destructive"
              className="gap-2 ml-auto"
            >
              <X className="w-4 h-4" />
              Exit
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}