import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Filter, Check, X, Search } from 'lucide-react';
import { Input } from './ui/input';

interface EventIdFilterProps {
  availableEventIds: string[];
  selectedEventIds: string[];
  onSelectionChange: (selectedIds: string[]) => void;
}

export function EventIdFilter({ 
  availableEventIds, 
  selectedEventIds, 
  onSelectionChange 
}: EventIdFilterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      // Focus search input when dropdown opens
      setTimeout(() => searchInputRef.current?.focus(), 0);
    } else {
      // Clear search when dropdown closes
      setSearchTerm('');
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const toggleEventId = (eventId: string) => {
    if (selectedEventIds.includes(eventId)) {
      onSelectionChange(selectedEventIds.filter(id => id !== eventId));
    } else {
      onSelectionChange([...selectedEventIds, eventId]);
    }
  };

  const selectAll = () => {
    onSelectionChange([...availableEventIds]);
  };

  const clearAll = () => {
    onSelectionChange([]);
  };

  // Filter event IDs based on search term
  const filteredEventIds = availableEventIds.filter(eventId =>
    eventId.includes(searchTerm)
  );

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        onClick={() => setIsOpen(!isOpen)}
        variant="outline"
        className="gap-2"
      >
        <Filter className="w-4 h-4" />
        Filter by Event ID
        {selectedEventIds.length > 0 && (
          <span className="ml-1 bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full">
            {selectedEventIds.length}
          </span>
        )}
      </Button>

      {isOpen && (
        <div className="absolute top-full mt-2 left-0 z-50 w-72 bg-white rounded-lg shadow-lg border border-slate-200">
          <div className="p-3 border-b border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-slate-700">
                Select Event IDs
              </span>
              <div className="flex gap-2">
                <button
                  onClick={selectAll}
                  className="text-xs text-blue-600 hover:text-blue-700 hover:underline"
                >
                  Select All
                </button>
                <button
                  onClick={clearAll}
                  className="text-xs text-slate-600 hover:text-slate-700 hover:underline"
                >
                  Clear
                </button>
              </div>
            </div>
            
            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                ref={searchInputRef}
                type="text"
                placeholder="Search event ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 h-8 text-sm"
              />
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto">
            {availableEventIds.length === 0 ? (
              <div className="p-4 text-center text-sm text-slate-500">
                No event IDs available
              </div>
            ) : filteredEventIds.length === 0 ? (
              <div className="p-4 text-center text-sm text-slate-500">
                No event IDs match "{searchTerm}"
              </div>
            ) : (
              <div className="p-2">
                {filteredEventIds.sort((a, b) => parseInt(a) - parseInt(b)).map((eventId) => {
                  const isSelected = selectedEventIds.includes(eventId);
                  return (
                    <button
                      key={eventId}
                      onClick={() => toggleEventId(eventId)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-left transition-colors ${
                        isSelected
                          ? 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 ${
                          isSelected
                            ? 'bg-blue-600 border-blue-600'
                            : 'border-slate-300'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="text-sm font-medium">Event ID {eventId}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {selectedEventIds.length > 0 && (
            <div className="p-3 border-t border-slate-200 bg-slate-50">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">
                  {selectedEventIds.length} selected
                </span>
                <Button
                  onClick={() => setIsOpen(false)}
                  variant="ghost"
                  size="sm"
                  className="h-7"
                >
                  Apply Filter
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}